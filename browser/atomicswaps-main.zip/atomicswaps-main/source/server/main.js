'use strict';

require("./server.js").StartServer();